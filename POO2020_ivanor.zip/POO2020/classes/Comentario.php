<?php

class Comentario extends DataBase{
    /** 
     * @var int Identificador 
     * @access private
    */
    private $id;
    /** 
     * @var string Comentário
     * @access private
    */
    private $comentario;
    /** 
     * @var object Notícia
     * @access private
    */
    private $noticia;
    /** 
     * @var string Nome do usuário
     * @access private
    */
    private $nomeUsuario;



    public function excluir($id, $id_materia){

        if(isset($_SESSION['user'])){
            if($id){
                if($this->delete("comentario", "id", $id, )){
                    echo "Comentário excluído.";
                }else{
                    echo "Falha ao excluir o comentário<br>";
                    
                }
                 header("location:".HOME_URI."noticia/materia/".$id_materia);
            }
        }
    }

}