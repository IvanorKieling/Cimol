<?php

/**
 * Noticia- Classe Noticia
 * @version 1.0
 * @author Ivanor
 * @since 0.1
 */
class Contato extends DataBase{
    /** 
     * @var int Identificador 
     * @access private
    */
    private $id;
    /** 
     * @var string nome
     * @access private
    */
    private $nome;
    /** 
     * @var text mensagem 
     * @access private
    */
    private $mensagem;
    /** 
     * @var text endereco 
     * @access private
    */
    private $endereco;
    /** 
     * @var date data 
     * @access private
    */
    private $data;

    /** 
     * @var array Lista de comentários
     * @access private
    */
    private $comentarios;
    /**
     * Método index
     * 
     */
    public function index(){
        require PATH .'/views/tema/header.php';
        require PATH .'/views/tema/nav.php';
        require PATH .'/views/tema/msg.php';
        			
        if(isset($_SESSION['user']) && $_SESSION['user']['perfil']=='admin')
            $this->listar();
        else
            require PATH .'/views/paginas/contatos/form_contatos.php';
        require PATH .'/views/tema/footer.php';
            
        
        
    }
    /**
     * Método listar
     * 
     */
    public function listar(){
        $resultado= $this->query("SELECT * FROM contato");
        $contatos=null;
        if($resultado->rowCount() > 0){
			// Retorna a consulta
			While($item=$resultado->fetch(PDO::FETCH_ASSOC)){
				$contato[]=$item;
            }
            if(isset($contato)){
                echo "<h1 class='container alert alert-info text-center mb-5 shadow rounded'>Mensagens</h1>";
                foreach($contato AS $pessoa){
                    $data = date_create($pessoa['data']);
                    echo "<section class='container text-justify mb-5 rounded p-3 shadow'>";
                    echo "<a href='".HOME_URI."/contato/excluir/".$pessoa['id']."'><abbr title='Excluir'><svg width='1.5em' height='1.5em' viewBox='0 0 16 16' class='bi bi-trash-fill' fill='red' xmlns='http://www.w3.org/2000/svg'>
                    <path fill-rule='evenodd' d='M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5a.5.5 0 0 0-1 0v7a.5.5 0 0 0 1 0v-7z'/>
                  </svg></abbr></a><br>";
                    echo "<h5 class='d-inline'><b>Nome: </b></h5><span class='lead'>".$pessoa['nome']."</span><br>";
                    echo "<h5 class='d-inline'><b>Email: </b></h5><span class='lead'>".$pessoa['email']."</span><br>";
                    echo "<h5 class='d-inline'><b>Telefone: </b></h5><span class='lead'>".$pessoa['telefone']."</span><br>";
                    echo "<h5 class='d-inline'><b>Mensagem: </b></h5><span class='lead'>".$pessoa['mensagem']."</span><br>";
                    echo "<h5 class='d-inline'><b>Data da postagem: </b></h5><span class='lead'>".date_format($data,'d/m/Y')."</span><br>";                    
                    echo "</section>";
                    
                }
            }else{
                echo "<h3>Não há mensagens de contatos</h3>";
            }            
        }
    }
    /**
     * Método salvar
     * 
     */
    public function salvar(){

        if(isset($_POST['enviar'])){

            $colunas[]=array('nome'=>$_POST['nome'], 'email'=>$_POST['email'], 'telefone'=>$_POST['telefone'], 'mensagem'=>$_POST['mensagem'], 'data'=>date('Y-m-d'));


            if($this->insert('contato',$colunas)){
                $msg['msg']="Contato inserido com sucesso!";
                $msg['class']="success";
            }else{
                var_dump($colunas);
                $msg['msg']="Falha ao inserir o contato";
                $msg['class']="danger";
            }
            $_SESSION['msg'][]=$msg;
            

        }else{
            $msg['msg']="Falha! Provavelmente, está faltando algum campo (nome, email, telefone, mensagem, data)";
            $msg['class']="danger";
        }
        header("location:".HOME_URI);        
    }
    /**
     * Método excluir
     * 
     */
    public function excluir($id){
        if(isset($_SESSION['user']))
            if($_SESSION['user']['perfil']=='admin'){
                if(isset($_SESSION['user'])){
                    if($id){
                        if($this->delete("contato", "id", $id, )){
                            echo "Contato excluída.";
                        }else{
                            echo "Falha ao excluir o contato<br>";
                            
                        }
                        header("location:".HOME_URI."contato");
                    }
                }
                header("location:".HOME_URI."contato");
            }
    }

}