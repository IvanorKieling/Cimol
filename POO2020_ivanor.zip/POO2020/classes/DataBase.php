<?php

/**
 * DataBase- Classe para gerenciamento da base de dados
 *
 * @since 0.1
 */
class DataBase
{
	
	
	/** 
     * @var object PDO
     * @access private
    */
	private $pdo;
	
	/**
	 * Construtor da classe
	 *
	 * @since 0.1
	 * @access public
	 */
	public function __construct() {
		//Obtem intancia PDO
		$this->pdo=Conexao::getInstance();
    	
	} // __construct
	
	
	
	/**
	 * query - Consulta PDO
	 *
	 * @since 0.1
	 * @access public
	 * @param $sql String  Consulta a ser executada no banco de dados
	 * @param $data_array Array  Lista de valores a serem vinculados a consulta.
	 * @return object|bool Retorna a consulta ou falso
	 */
	public function query( $sql, $data_array = null ) { 
		// Prepara para executar a query
		/*
		Este método transforma uma declaração SQL na forma de um “objeto declaração” 
		que pode ser manipulado por alguns métodos específicos.
		*/

		$stmt      = $this->pdo->prepare($sql); 
		if (!$stmt) {
			echo "\nPDO::errorInfo():\n";
			print_r($pdo->errorInfo());
		}else{
			/*echo "stmt";
			var_dump($stmt);*/
		}
		/* Se Houver valores a serem vinculados */
		if($data_array){
			/**Executar a query com os valores vinculados */
			$check_exec = $stmt->execute($data_array);
			/*echo "data_array";
			var_dump($data_array);
			echo "check_exec";
			var_dump($check_exec);*/


		}else{
			/*Executa a query */
			$check_exec = $stmt->execute();
		}
		// Verifica se a consulta aconteceu
		if ( $check_exec ) {
			/*Retorna objeto com o conteúdo da consulta */
			return $stmt;
		} else {
		 		
			// Retorna falso
			return false;
			
		}
    }
    
	/**
	 * SELECT
	 *
	 * Lista registros da tabela
	 *
	 * @since 0.1
	 * @access protected
	 * @param string $table Nome da tabela
	 * @param array $cols lista de colunas
	 * @param array $where lista de chaves e valor para definir as condições da consulta
	 * @return Array Retorna a lista de registros
	 */
    public function select($table, $cols=null, $where=null){
        /**Verifica se foi passado uma lista de colunas a serem exibidas na consulta */
        if($cols){
			/**Inicia a montagem da string contendo o SQL a ser executado no Banco de dados */
			$sql="SELECT ";
			/*Adiciona as colunas pasadas ao SQL */
			foreach($cols AS $col){
                $sql.=$col.",";
			}
			//Remove aultima virgula
			$sql=substr($sql,0,-1);
           

            $sql.=" FROM ".$table;
        }else{
			/**Monta a string contendo o SQL a ser executado no Banco de dados */
			$sql="SELECT * FROM ".$table;
        }
		/**Verifica a existencia de parametros para filtrar a consulta */
        if($where){
            $sql.=" WHERE ";
            $num_cols=1;
            foreach($where AS $col=>$val){
                if($num_cols>1){
                    $sql.=" AND ";
                }

                $sql.=$col."='".$val."' ";
                $num_cols++;
            }
        }
        
        $retorno=$this->query($sql);
        if($retorno->rowCount()>0){
            $resultado=null;
            while($item=$retorno->fetch(PDO::FETCH_ASSOC)){
                $resultado[]=$item;
            }

            return $resultado;
        }
        return null;

	}//select
	
	/**
	 * insert - Insere valores
	 *
	 * Insere os valores e tenta retornar o último id enviado
	 *
	 * @since 0.1
	 * @access public
	 * @param string $table O nome da tabela
	 * @param array ... Ilimitado número de arrays com chaves e valores
	 * @return object|bool Retorna a consulta ou falso
	 */
	public function insert($table, $data ) {
		
		// Configura o array de colunas
		$cols = array();
		
		// Configura o valor inicial do modelo
		$place_holders = '(';
		
		// Configura o array de valores
		$values = array();
		
		// O $j  assegura que colunas serão configuradas apenas uma vez
		$j = 0;
		
		//var_dump($data);

		// É preciso enviar pelo menos um array de chaves e valores
		if(!isset( $data[0] ) || !is_array($data[0]) ) {
			//conteúdo inválido
			return;
		}
		
		// Faz um laço nos argumentos
		for ( $i=0; $i < count($data); $i++ ) {
			// Obtém as chaves como colunas e valores como valores
			foreach ($data[$i] as $col=>$val) {
				
				// A primeira volta do laço configura as colunas
				if ( $i === 0 ) {
					$cols[] = "$col";
				}
				
				if ( $j <> $i ) {
					// Configura os divisores
					$place_holders .= '), (';
				}
				
				// Configura os place holders do PDO
				$place_holders .= '?, ';
				
				// Configura os valores a serem enviados
				$values[] = $val;
				
				$j = $i;
			}
			
			// Remove os caracteres extra dos place holders
			$place_holders = substr( $place_holders, 0, strlen( $place_holders ) - 2 );
		}
		
		// Separa as colunas por vírgula
		$cols = implode(', ', $cols);
		
		// Cria a declaração para enviar ao PDO
		$stmt = "INSERT INTO $table ( $cols ) VALUES $place_holders) ";
		// Insere os valores
		$insert = $this->query( $stmt, $values );

		// Verifica se a consulta foi realizada com sucesso
		if ( $insert ) {
			// Verifica se temos o último ID enviado
			if ( method_exists( $this->pdo, 'lastInsertId' ) 
				&& $this->pdo->lastInsertId() 
			) {
				// Configura o último ID
				$this->last_id = $this->pdo->lastInsertId();
			}
			
			// Retorna a consulta
			return $insert;
		}
		// The end :)
		return;
	} // insert

	/**
	 * Update simples
	 *
	 * Atualiza uma linha da tabela baseada em um campo
	 *
	 * @since 0.1
	 * @access protected
	 * @param string $table Nome da tabela
	 * @param string $where_field WHERE $where_field = $where_field_value | Lista de colunas de fazem parte do filtro WHERE
	 * @param string $where_field_value WHERE $where_field = $where_field_value | Lista de valores para as colunas do WHERE
	 * @param array $values Um array com os novos valores
	 * @return object|bool Retorna a consulta ou falso
	 */
	public function update( $table, $where_field, $where_field_value, $values ) {
		// Você tem que enviar todos os parâmetros
		if ( empty($table) || empty($where_field) || empty($where_field_value)  ) {
			return;
		}
		
		// Começa a declaração
		$stmt = " UPDATE $table SET ";
		
		// Configura o array de valores
		$set = array();
		
		// Configura a declaração do WHERE campo=valor
		$where = " WHERE $where_field = ? ";
		
		// Você precisa enviar um array com valores
		if ( !is_array( $values ) ) {
			return;
		}
		
		// Configura as colunas a atualizar
		foreach ( $values as $column => $value ) {
			$set[] = " $column = ?";
		}
		
		// Separa as colunas por vírgula
		$set = implode(', ', $set);
		
		// Concatena a declaração
		$stmt .= $set . $where;
		
		// Configura o valor do campo que vamos buscar
		$values[] = $where_field_value;
		
		// Garante apenas números nas chaves do array
		$values = array_values($values);
				
		// Atualiza
		$update = $this->query( $stmt, $values );
		
		// Verifica se a consulta está OK
		if ( $update ) {
			// Retorna a consulta
			return $update;
		}
		
		// The end :)
		return;
	} // update

	/**
	 * Delete
	 *
	 * Deleta uma linha da tabela
	 *
	 * @since 0.1
	 * @access protected
	 * @param string $table Nome da tabela
	 * @param string $where_field WHERE $where_field = $where_field_value
	 * @param string $where_field_value WHERE $where_field = $where_field_value
	 * @return object|bool Retorna a consulta ou falso
	 */
	public function delete( $table, $where_field, $where_field_value ) {
		// É necessário enviar todos os parâmetros
		if ( empty($table) || empty($where_field) || empty($where_field_value)  ) {
			return;
		}
		
		// Inicia a declaração
		$stmt = "DELETE FROM $table ";

		// Configura a declaração WHERE campo=valor
		$where = "WHERE $where_field = ? ";
		
		// Concatena tudo
		$stmt .= $where;
		
		// O valor que vamos buscar para apagar
		$values = array( $where_field_value );
		/*echo "Valores<br>";
		var_dump($values);
		echo "stmt";
		var_dump($stmt);*/
		
		
		// Apaga
	$delete = $this->query( $stmt, $values);

		
		// Verifica se a consulta está OK
		if ( $delete ) {
			// Retorna a consulta
			return $delete;
		}
		
		// The end :)
		return;
	} // delete

}