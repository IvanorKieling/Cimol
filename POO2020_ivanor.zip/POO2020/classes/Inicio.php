<?php

/**
 * Inicio- Classe Inicio
 * @version 1.0
 * @author Cândido
 * @since 0.1
 */
class Inicio extends DataBase{
    
    public function index(){
        include PATH."/views/paginas/inicio.php";
    }
    

    

}