<?php

/**
 * Noticia- Classe Noticia
 * @version 1.0
 * @author Ivanor
 * @since 0.1
 */
class Noticia extends DataBase{
    /** 
     * @var int Identificador 
     * @access private
    */
    private $id;
    /** 
     * @var string titulo
     * @access private
    */
    private $titulo;
    /** 
     * @var text descricao 
     * @access private
    */
    private $descricao;
    /** 
     * @var date data 
     * @access private
    */
    private $data;
    /** 
     * @var object  usuario 
     * @access private
    */
    private $usuario;
    /** 
     * @var string URL da imagem
     * @access private
    */
    private $imagem;
    /** 
     * @var array Lista de comentários
     * @access private
    */
    private $comentarios;
    /**
     * Método index
     * 
     */
    public function index(){
        $this->listar();
    }
    /**
     * Método listar
     * 
     */
    public function listar(){
        $resultado= $this->query("SELECT * FROM noticia");
        $noticias=null;
        if($resultado->rowCount() > 0){
			// Retorna a consulta
			While($item=$resultado->fetch(PDO::FETCH_ASSOC)){
				$noticia[]=$item;
            }
            
		}
		require PATH .'/views/tema/header.php';
        require PATH .'/views/tema/nav.php';
        require PATH .'/views/tema/msg.php';			
        require PATH .'/views/paginas/noticias/listarNoticias.php';
		require PATH .'/views/tema/footer.php';
    }
    /**
     * Método criar
     * 
     */
    public function criar(){
        require PATH .'/views/tema/header.php';
        require PATH .'/views/tema/nav.php';			
        require PATH .'/views/paginas/noticias/addNoticia.php';
		require PATH .'/views/tema/footer.php';
    }
    /**
     * Método salvar
     * 
     */
    public function salvar(){
        if(isset($_POST['titulo']) AND isset($_POST['descricao']) AND isset($_POST['enviar']) ){
            if(!empty($_POST['titulo']) AND !empty($_POST['descricao'])){
                if($_FILES['imagem']['size']>0){
                    $ext = strtolower(substr($_FILES['imagem']['name'],-4)); //Pegando extensão do arquivo
                    $nomeImagem = date("dmYHis") . $ext; //Definindo um novo nome para a imagem
                    $dir = UP_PATH; //Diretório para uploads 
                    move_uploaded_file($_FILES['imagem']['tmp_name'], $dir.$nomeImagem); //Fazer upload do arquivo
                    $colunas[]=array('titulo'=>$_POST['titulo'],'descricao'=>$_POST['descricao'],'data'=>date('Y-m-d'), 'usuario_id'=>$_SESSION['user']['id'], 'imagem'=>$nomeImagem);
                }else{
                    $colunas[]=array('titulo'=>$_POST['titulo'],'descricao'=>$_POST['descricao'],'data'=>date('Y-m-d'), 'usuario_id'=>$_SESSION['user']['id']);
                    
                }

                if($this->insert('noticia',$colunas)){
                    $msg['msg']="Notícia inserida com sucesso!";
                    $msg['class']="success";
                }else{
                    var_dump($colunas);
                    $msg['msg']="Falha ao inserir a notícia";
                    $msg['class']="danger";
                }
                $_SESSION['msg'][]=$msg;
            }

        }else{
            $msg['msg']="Falha! Provavelmente, está faltando algum campo (titulo, descricao, enviar)";
            $msg['class']="danger";
        }

        header("location:".HOME_URI);

    }
    /**
     * Método excluir
     * 
     */
    public function excluir($id){

        if(isset($_SESSION['user'])){
            if($id){
                if($this->delete("noticia", "id", $id, )){
                    echo "Notícia excluída.";
                }else{
                    echo "Falha ao excluir a notícia<br>";
                    
                }
                 header("location:".HOME_URI."noticia/");
            }
        }
    }
    /**
     * Método editar
     * 
     */
    public function editar(){
        if(isset($_SESSION['user'])){
            if(isset($_GET['path'])){
                $path=rtrim($_GET['path'],"/");
                $path=explode("/", $path);      
                require PATH .'/views/tema/header.php';
                require PATH .'/views/tema/nav.php';
                if(isset($path[2])){			
                    require PATH .'/views/paginas/noticias/form_editar_noticia.php';
                }
                require PATH .'/views/tema/footer.php';
                if(isset($_POST['enviar']) AND isset($_POST['titulo']) AND isset($_POST['descricao'])){
                    $sql = "UPDATE noticia SET titulo = '".$_POST['titulo']."', descricao = '".$_POST['descricao']."' WHERE id = '".$_POST['id']."'";
                    //var_dump($sql);
                    if($this->query($sql)){
                        $msg['msg']="Notícia alterada com sucesso";
                        $msg['class']="success";
                    }else{
                        $msg['msg']="Falha ao alterar a notícia";
                        $msg['class']="danger";
                    }
                    header("location:".HOME_URI."noticia/");
                }
            }
        }
    }
    /**
    * Método materia
    * 
    */
    public function materia($id){
        require PATH .'/views/tema/msg.php';
        require PATH .'/views/tema/header.php';
        require PATH .'/views/tema/nav.php';
        $consulta = $this->select('noticia', ['*'],['id'=>$id]);
        $data = date_create($consulta[0]['data']);
        if($id){
            echo "<div class='container'><h1 class='text-center mt-3'>".$consulta[0]['titulo']."</h1>";
            if(isset($consulta[0]['imagem'])){
                echo "<div class='d-flex justify-content-center'><div class='d-flex justify-content-center'><img src=../../uploads/".$consulta[0]['imagem']." class='img-fluid rounded mx-auto d-block w-50'></div></div>";
            }
            if(isset($_SESSION['user'])){
                if($_SESSION['user']['id']==$consulta[0]['usuario_id']){
                    echo "<a href='".HOME_URI."noticia/editar/".$consulta[0]['id']."'><abbr title='Editar'><svg width='1.7em' height='1.7em' viewBox='0 0 16 16' class='bi bi-pencil-fill' fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
                    <path fill-rule='evenodd' d='M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.5-.5V10h-.5a.499.499 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z'/>
                  </svg></abbr></a>
                    <a href='".HOME_URI."noticia/excluir/".$consulta[0]['id']."'><abbr title='Excluir'><svg width='1.7em' height='1.7em' viewBox='0 0 16 16' class='bi bi-trash-fill' fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
                    <path fill-rule='evenodd' d='M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5a.5.5 0 0 0-1 0v7a.5.5 0 0 0 1 0v-7z'/>
                  </svg></abbr></a>";
                }
            }
            echo "<p class='text-justify lead'>".$consulta[0]['descricao']."</p></div>";
            
            echo "<p class='container text-right'>Postado por <em>".$this->select("usuario", ['nome'], ['id'=>$consulta[0]['usuario_id']])[0]['nome']." em ".date_format($data,'d/m/Y')."</em></p>";
        }
        require PATH .'/views/paginas/noticias/comentarios.php';
        require PATH .'/views/tema/footer.php';        
    }

}