<div class='container'>    
    <form action="<?php echo HOME_URI;?>contato/salvar" method="post">
    <div class="form-group">
        <label for="nome" class='h4'>Nome</label>
        <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome" required>
    </div>
    <div class="form-group">
        <label for="email" class='h4'>Email</label>
        <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Email" required>
        <small id="emailHelp" class="form-text text-muted">Jamais compartilharemos o seu email sem a sua permissão.</small>
    </div>
    <div class="form-group">
        <label for="telefone" class='h4'>Telefone</label>
        <input type="text" class="form-control" id="telefone" name="telefone" pattern="[0-9]+$" placeholder="Telefone" required>
    </div>
    <div class="form-group">
        <label for="mensagem" class='h4'>Mensagem</label>
        <textarea class="form-control" id="mensagem" rows="3" name="mensagem"></textarea>
    </div>

    <button type="submit" class="btn btn-primary mb-5" name="enviar">Enviar</button>
    </form>
</div>