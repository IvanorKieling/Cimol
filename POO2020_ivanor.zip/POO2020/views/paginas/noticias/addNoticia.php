<?php
if($_SESSION['user']){
?>
    <div class='container'>
        <form action="<?php echo HOME_URI;?>noticia/salvar" method="post" class="md-form m-5" enctype="multipart/form-data">
        <fieldset>
                <legend class='h2 text-center alert alert-info'>INSERIR NOTÍCIA</legend>
                <input type="hidden" name="id" />
                <div class="input-group">
                    <label for="titulo" class="input-group-addon h4 m-2">Título</label>
                    <input type="text" class="form-control m-1 ml-5" id="titulo" name="titulo" 
                    placeholder="Título da notícia"/>
                </div>
                <div class="input-group">
                    <label for="descricao" class="input-group-addon h4 m-2">Descrição</label>
                    <textarea type="text" class="form-control m-1" id="descricao" rows="10" name="descricao" 
                    placeholder="Descrição da notícia"></textarea>
                </div>
                <div class="input-group">
                    <label for="imagem" class="input-group-addon h4 m-2">Imagem</label>
                    <input type="file" class="form-control m-1 ml-4" id="imagem" name="imagem" accept=".jpg, .jpeg, .gif, .png"/>
                </div>

                <div class='d-flex justify-content-center w-50'>
                    <input type="submit" class='btn btn-primary mt-2 w-50' name="enviar" value="Enviar" />
                </div>
            </fieldset>
        </form>
    </div>
<?php
}else{
    header("location:".HOME_URI."usuario/");
}
?>