</form>
<div class='container'>
    <form method="POST" class="form">
        <fieldset>
            <input type='hidden' name='id'>            
            <textarea name='comentario' style="width: 100%;" rows='5'></textarea>
            <div class='w-50'>
                <input type="submit" class='btn btn-success btn-block w-50' name="comentar" value="Comentar" />
            </div>
        </fieldset>
    </form>
    <?php
        if(isset($_POST['comentar'])&&(strlen(trim($_POST['comentario'])))){
            if(!empty($_POST['comentario'])){
                if(isset($_SESSION['user']))
                    $colunas[]=array('comentario'=>$_POST['comentario'],'noticia_id'=>$id,'nome_usuario'=>$_SESSION['user']['nome']);
                else
                    $colunas[]=array('comentario'=>$_POST['comentario'],'noticia_id'=>$id,'nome_usuario'=>'Anônimo');
                

                if($this->insert('comentario',$colunas)){
                    $msg['msg']="Sucesso!";
                    $msg['class']="success";
                }else{
                    $msg['msg']="Falha ao inserir o comentário";
                    $msg['class']="danger";
                }
                $_SESSION['msg'][]=$msg;
            }
        }
    ?>

    <!-- Lista de comentários -->
    <h3 class='mt-4 mb-3 text-center alert alert-info'>Comentários</h3>
    <div class='container text-justify h5'>
    <?php
    $comentarios = $this->select('comentario', ['*'], ['noticia_id'=>$id]);
    if($comentarios){
        foreach($comentarios as $comentario){
            echo "<p><b>".$comentario['nome_usuario']."</b> - ".$comentario['comentario'];
            if(isset($_SESSION['user'])){
                if($_SESSION['user']['nome']==$comentario['nome_usuario']||$_SESSION['user']['perfil']=='admin'){
                    echo " <a href='".HOME_URI."comentario/excluir/".$comentario['id']."/".$id."' class=''><abbr title='Excluir'><svg width='1em' height='1em' viewBox='0 0 16 16' class='bi bi-trash-fill' fill='red' xmlns='http://www.w3.org/2000/svg'>
                    <path fill-rule='evenodd' d='M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5a.5.5 0 0 0-1 0v7a.5.5 0 0 0 1 0v-7z'/>
                  </svg></abbr></a>";
                }
            }
            echo "</p><hr>";
        }
    }
    ?>
    </div>
</div>

