<main>
    <form action="<?php echo HOME_URI;?>noticia/editar" method="POST" class="form">
        <fieldset>
            <legend>Alterar Notícia</legend>
            <?php
                $resultado = $this->select("noticia", ['titulo', 'descricao'], ["id"=>$path[2]]);
            ?>
            <input type="hidden" name="id" value="<?php echo $path[2] ?>"/>
            <div class="input-group">
                <span class="input-group-addon">Título</span>
                <input type="text" class="form-control" name="titulo" 
                 value="<?php echo $resultado[0]['titulo']?>"/>
            </div>
            <div class="input-group">
                <span class="input-group-addon">Descrição</span>
                <textarea type="text" class="form-control" name="descricao" rows="10">
                <?php echo $resultado[0]['descricao']?>
                </textarea>
            </div>
            <div>
                <input type="submit" class='btn btn-primary btn-block' name="enviar" value="Enviar" />
            </div>
        </fieldset>
    </form>

</main>