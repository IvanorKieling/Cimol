<main>
    <form action="<?php echo HOME_URI;?>usuario/editar" method="POST" class="form">
        <fieldset>
            <legend>Alterar Cadastro do Usuário</legend>
            <?php
                $resultado = $this->select("usuario", ['nome', 'email'], ["id"=>$path[2]]);
            ?>
            <input type="hidden" name="id" value="<?php echo $path[2] ?>"/>
            <div class="input-group">
                <span class="input-group-addon">Nome</span>
                <input type="text" class="form-control" name="nome" 
                 value="<?php echo $resultado[0]['nome']?>"/>
            </div>
            <div class="input-group">
                <span class="input-group-addon">Email</span>
                <input type="text" class="form-control" name="email" 
                value="<?php echo $resultado[0]['email']?>"/>
            </div>
            <div>
                <input type="submit" class='btn btn-primary btn-block' name="enviar" value="Enviar" />
            </div>
        </fieldset>
    </form>

</main>