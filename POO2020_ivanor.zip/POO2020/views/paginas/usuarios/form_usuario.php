<div class='container'>
    <div class="container shadow">
        <form action="<?php echo HOME_URI;?>usuario/salvar" method="POST" class="form m-5">
            <fieldset>
                <legend class='h2 text-center'>Cadastro de usuários</legend>
                <input type="hidden" name="id" />
                <div class="input-group m-3">
                    <label class="h4 m-2" for='nome'>Nome</label>
                    <input type="text" class="form-control m-1" name="nome" id='nome'
                    placeholder="Nome do usuário"/>
                </div>
                <div class="input-group m-3">
                    <label class="h4 m-2" for='email'>Email</label>
                    <input type="text " class="form-control m-1" name="email" id='email'
                    placeholder="Email"/>
                </div>
                <div class="w50 d-flex justify-content-center">
                    <div class='w-50 m-4 mb-5 d-flex justify-content-center'>
                        <input type="submit" class='btn btn-primary btn-block w-50' name="enviar" value="Enviar" />
                    </div>
                </div>
            </fieldset>
        </form>
    </div>
</div>