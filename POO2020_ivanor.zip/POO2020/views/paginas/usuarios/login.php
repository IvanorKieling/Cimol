<main>
    <div class='container'>
        <form action="<?php echo HOME_URI;?>usuario/autenticar" method="POST">
        <div class="form-group">
            <label for="InputEmail" class='h4'>Endereço de e-mail</label>
            <input type="email"  name="email" class="form-control" id="inputEmail" aria-describedby="emailHelp" placeholder="Informe o email" required>
            <small id="emailHelp" class="form-text text-muted">Nunca compartilharemos seu email com mais ninguém.</small>
        </div>
        <div class="form-group">
            <label for="inputPassword" class='h4'>Senha</label>
            <input type="password" name="senha" class="form-control" id="inputPassword1" placeholder="Senha" required>
        </div>
        
        <button type="submit" class="btn btn-primary">Autenticar</button>
        </form>
    </div>
</main>