<div class='container'>
    <?php 
    if(!isset($_SESSION['user'])){
        exit(0);
    }
    ?>
    <div class='container text-center alert alert-info mt-5 mb-5'>
        <h2>Olá, <?php echo $_SESSION['user']['nome']?> </h2>
        <h4>Este deve ser o seu primeiro acesso, portanto defina uma nova senha.</h4>
    </div>
    <form action="<?php echo HOME_URI;?>usuario/salvarSenha" method="POST" class="form">
        <fieldset>
            <input type="hidden" name="id" value="<?php echo $_SESSION['user']['id']  ?>"/>
            
            <div class="input-group">
                <span class="input-group-addon h4 m-2">Nova senha: </span>
                <input type="password" class="form-control m-1" name="senha" placeholder="Nova senha"/>
            </div>
            <div class="container d-flex justify-content-center w-50">
                <input type="submit" class='btn btn-primary btn-block m-2 mb-5 mt-3 w-50' name="enviar" value="Enviar" />
            </div>
        </fieldset>
    </form>

</container>