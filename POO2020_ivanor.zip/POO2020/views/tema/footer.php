<footer style="height: 150px">
	<p>Escola Técnica Estadual Monteiro Lobato</p>
	<p> Curso Técnico em Informática </p>
	<p>Disciplina de Criação de Sites</p>
	<p>Professor Cândido Farias</p>
    </footer>
</body>
</html>